const express = require('express');

const router = express.Router();
const userController = require('../Controllers/UserControllers/UserController');
router.get('/user',(req,res)=>{
    res.status(200).json({message:"user Apis yet to be come"})
});
router.get('/userList',userController.getAllUsersList);
router.get('/userList1',userController.decipherGetAllUsersList);
router.post('/registerUser',userController.registerNewUser);

module.exports = router;