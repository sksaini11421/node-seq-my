const express = require('express');

const router = require('../Routers/Router');

router.get('/users',(req,res) =>{
    res.send({"message":`users walaaaaaaaaa`})
})

module.exports = router;