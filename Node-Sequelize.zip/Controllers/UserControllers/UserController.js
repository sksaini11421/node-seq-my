const response = require('../../Helpers/ResponseHandler');
// const adminService = require('../../services/adminServices/adminServices');
const crypto = require('node:crypto');
const userServices = require('../../Services/UserServices');

module.exports = {
    getAllUsersList: async (req,res) => {
    console.log("adminUsersController => getAllUsersList");
        try {
            let {  } = req.query;
            // let secretKey = `ShashankSaini@123`;
            // const hash = crypto.createHmac('sha256',secretKey)
            //                     .update(`Shashank Saini`)
            //                 .digest('hex')
            const cipher = crypto.createCipher('aes192','Shashank');
            let encrypted = cipher.update(`Shasnk hello`,'utf-8','hex');
            encrypted += cipher.final('hex');
            // const challenge = crypto.Certificate.exportChallenge(spkac);
            return response.success(res, 'Users List Fetched Successully', encrypted);
        }
        catch(error)
        {
            console.log(error.message);
            return response.badImplementation(res, 'Internal Server Error');
        }
    },
    decipherGetAllUsersList: async (req,res) => {
        console.log("adminUsersController => getAllUsersList");
        try {
            let {  } = req.query;
            // let secretKey = `ShashankSaini@123`;
            // const hash = crypto.createHmac('sha256',secretKey)
            //                     .update(`Shashank Saini`)
            //                 .digest('hex')
            const decipher = crypto.createDecipher('aes192','Shashank');
            let encrypted = `71d9622da9e29b0c05167a429a982741`;

            let decrypted = decipher.update(encrypted,'hex','utf8');
            decrypted = decrypted + decipher.final('utf-8');

            
            // const challenge = crypto.Certificate.exportChallenge(spkac);
            return response.success(res, 'Users List Fetched Successully', decrypted);
        }
        catch(error)
        {
            console.log(error.message);
            return response.badImplementation(res, 'Internal Server Error');
        }
    },
    registerNewUser: async (req,res) => {
        console.log("adminUsersController => register New User");
        try {
            console.log(req.body)
            let { first_name,last_name,email,country_code,phone_number  } = req.body;
            const userData = await userServices().registerUser({first_name:first_name,last_name:last_name,email:email,country_code:country_code,phone_number:phone_number});
            return response.success(res, 'Users registered Successully' , userData);
        }
        catch(error)
        {
            console.log(error.message);
            return response.badImplementation(res, 'Internal Server Error');
        }
    },
}
