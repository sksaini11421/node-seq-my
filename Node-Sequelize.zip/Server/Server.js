const express = require('express');
const app = express();
require('dotenv').config();
const dbConfig = require('../Models/Model');
const apiRoutes = require('../Routers/Router');

app.get('/',(req,res)=>{
    res.status(200).json({message:"Welcome to India Assists"});
})


const setUpBodyParser = () => {
    // app.use(express.urlencoded({extended:true}));
    app.use(express.json());
}

const setUpDatabase = () =>{
    dbConfig.connectionCheck.then((data)=>{
        console.log(`Database Connected`);
    }).catch((error)=>{
        console.log(error);
    })
}

const setUpRoutes = () =>{
    app.use('/v1',apiRoutes);
}

const setUp404Handler = () => {
    app.use((req,res)=>{
        res.status(404)
        .json({message:"route not found",
            status:404
            })
    })
}

const intialize = () => {
    setUpBodyParser();
    setUpDatabase();
    setUpRoutes();
    setUp404Handler();
}

intialize();


module.exports = app;