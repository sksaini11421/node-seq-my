const app = require('./Server/Server');

const Server = require('http').createServer(app);

Server.listen(process.env.PORT,()=>{
    console.log(`Server is Running at ${process.env.PORT}`)
})