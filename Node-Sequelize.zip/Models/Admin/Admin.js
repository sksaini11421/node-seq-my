const { DataTypes } = require('sequelize');
const sequelize = require('../../Db/Database');

const Admin = sequelize.define('Admin', {
    admin_id: {
        autoIncrement : true,
        primaryKey: true,
        type : DataTypes.BIGINT,
    },
    first_name: {
        type : DataTypes.STRING,
    },
    last_name: {
        type : DataTypes.STRING,
    }
}, {
    sequelize,
    modelName:'Admin',
    tableName : 'admin'
})

module.exports = Admin;