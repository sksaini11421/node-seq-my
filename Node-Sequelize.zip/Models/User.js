const { DataTypes } = require('sequelize');
const sequelize = require('../Db/Database');

const User = sequelize.define('User', {
    user_id: {
        autoIncrement : true,
        primaryKey: true,
        type : DataTypes.BIGINT,
        
    },
    first_name: {
        type : DataTypes.STRING,
    },
    last_name: {
        type : DataTypes.STRING,
    },
    email : {
        type : DataTypes.STRING
    },
    country_code : {
        type : DataTypes.STRING
    },
    phone_number : {
        type : DataTypes.INTEGER
    },
    is_active : {
        type : DataTypes.SMALLINT,
        defaultValue : 1
    }
}, {
    sequelize,
    modelName:'User',
    tableName : 'users'
})

module.exports = User;