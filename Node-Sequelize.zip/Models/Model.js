const {Sequelize} = require('sequelize');
const db = require('../Db/Database');
const userModel = require('../Models/User')
const adminModel = require('../Models/Admin/Admin')

function connectionCheck() {
    return new Promise((resolve,reject) => {
        try{
            db.authenticate();
            if(!db.authenticate())
            {
                if(connection) connection.release();
                reject(err);
            }
            else
            {
                db.sync({ alter: true});
                resolve('successfully connected');
            }
        }
        catch(error) {
            console.log(`Database connection Failed `,error.message);
        }
    })
}

// function connectionRelease() {
//     return new Promise((resolve,reject) => {
//         try{
//             db.authenticate();
//             if(!db.authenticate())
//             {
//                 if(connection) connection.release();
//                 reject(err);
//             }
//             else
//             {
//                 resolve('successfully connected');
//             }
//         }
//         catch(error) {
//             console.log(`Database connection Failed `,error.message);
//         }
//     })
// }

module.exports = {
    connectionCheck: connectionCheck()
}