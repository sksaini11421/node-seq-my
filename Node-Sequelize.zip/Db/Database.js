const {Sequelize} = require('sequelize');
require('dotenv').config();

const db = {};

const dbOptions = {
    port: process.env.DB_PORT,
    host: process.env.DB_HOST,
    pool: {
        max: 30,
        min: 0,
        acquire: 10000000,
        idle: 1000000
    }
};
const sequelize = new Sequelize(process.env.DB_NAME, process.env.DB_USER,process.env.DB_PASWORD, {
    dbOptions,
    dialect: process.env.DB_DIALECT
});
module.exports = sequelize;
