const userModel = require('../Models/User');

module.exports = () => {
    const registerUser = (data) => {
        return new Promise((resolve,reject) =>{
            let orm = userModel.create(data);
            orm.then(resolve).catch(reject)
        })
    };
    return {
        registerUser
    }
}
